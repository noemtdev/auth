the webserver starts running as soon as you initialize it 
<br>
run Auth.setup() first if you want to use default paths
<br>
the last 2 arguments are not required and they will be set to the default paths from setup()
<br>
The bot has to be in **py-cord**
<br>
Usage: 
<br>
```py
from noms.auth import setup, Auth
setup() # do this once only
```